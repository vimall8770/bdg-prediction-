import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload } from "lucide-react";
import { motion } from "framer-motion";
import Tesseract from "tesseract.js";

export default function BDGPredictor() {
  const [numbers, setNumbers] = useState("");
  const [prediction, setPrediction] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const getPrediction = (numList) => {
    if (numList.length === 0) return null;
    const lastNum = numList[numList.length - 1];
    let predictedNum = (parseInt(lastNum) + 1) % 10;
    let bigSmall = predictedNum >= 5 ? "Big" : "Small";
    let color = predictedNum % 2 === 0 ? "Red" : "Green";

    return { number: predictedNum, bigSmall, color };
  };

  const handlePredict = () => {
    const numArray = numbers
      .split(",")
      .map((n) => n.trim())
      .filter((n) => n !== "" && !isNaN(n));
    const prediction = getPrediction(numArray);
    if (prediction) {
      setPrediction(prediction);
      setHistory([
        { input: [...numArray], output: prediction },
        ...history,
      ]);
    }
  };

  const handleScreenshotUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setLoading(true);

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const result = await Tesseract.recognize(reader.result, "eng", {
          logger: (m) => console.log(m),
        });

        const rawText = result.data.text;
        const extractedNumbers = rawText
          .match(/\d+/g)
          ?.slice(0, 10)
          .join(", ") || "";

        setNumbers(extractedNumbers);
        setLoading(false);
      } catch (error) {
        console.error("OCR failed", error);
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="p-4 max-w-md mx-auto space-y-4">
      <Card>
        <CardContent className="space-y-2 p-4">
          <h2 className="text-xl font-bold">BDG Predictor</h2>
          <Input
            placeholder="Enter last 10 numbers, comma-separated"
            value={numbers}
            onChange={(e) => setNumbers(e.target.value)}
          />

          <div className="space-y-2">
            <label className="block text-sm font-medium">Upload Screenshot</label>
            <Input type="file" accept="image/*" onChange={handleScreenshotUpload} />
            {loading && <p className="text-sm text-blue-500">Processing image with OCR...</p>}
          </div>

          <Button onClick={handlePredict}>Predict Next</Button>

          {prediction && (
            <motion.div
              className="mt-4 p-3 rounded-xl bg-gray-100"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <p><strong>Prediction:</strong></p>
              <p>Number: {prediction.number}</p>
              <p>Big/Small: {prediction.bigSmall}</p>
              <p>Color: {prediction.color}</p>
            </motion.div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-2">
          <h3 className="font-semibold">Prediction History</h3>
          {history.length === 0 && <p>No predictions yet.</p>}
          {history.map((entry, index) => (
            <div
              key={index}
              className="border p-2 rounded-md text-sm bg-white"
            >
              <p>Input: {entry.input.join(", ")}</p>
              <p>Prediction: {entry.output.number} ({entry.output.bigSmall}, {entry.output.color})</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}